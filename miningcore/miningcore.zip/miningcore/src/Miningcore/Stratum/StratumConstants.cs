using System;
using System.Collections.Generic;
using System.Text;

namespace Miningcore.Stratum
{
    public class StratumConstants
    {
        public static readonly Encoding Encoding = new UTF8Encoding(false);
    }
}
