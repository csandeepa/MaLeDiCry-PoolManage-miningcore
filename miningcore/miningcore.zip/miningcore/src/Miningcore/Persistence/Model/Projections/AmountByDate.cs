﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Miningcore.Persistence.Model.Projections
{
    public class AmountByDate
    {
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
    }
}
